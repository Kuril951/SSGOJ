/*
 *	Bulgarian translation
 *	Author:		Valentin Hristov
 *	Company:	SOFTKIT Bulgarian
 *	Site:		http://www.softkit-bg.com
 */
editArea.add_lang("bg",{
test_select: "избери таг",
test_but: "тествай копието"
});
