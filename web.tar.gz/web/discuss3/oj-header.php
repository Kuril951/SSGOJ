<?php 
	require_once('../include/db_info.inc.php');
   ob_start();
?>
