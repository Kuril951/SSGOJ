 <?php

	//oj-header.php
	$MSG_FAQ="F.A.Qs";

	$MSG_BBS="برد";

	$MSG_HOME="خانه";

	$MSG_PROBLEMS="مسئله ها";

	$MSG_STATUS="وضعیت ها";

	$MSG_RANKLIST="رتبه بندی";

	$MSG_CONTEST="مسابقه ها";
   
$MSG_RECENT_CONTEST="Recent";
	
	$MSG_LOGOUT="خروج";

	$MSG_LOGIN="ورود";
	$MSG_LOST_PASSWORD="Lost Password";
	$MSG_REGISTER="عضویت";

	$MSG_ADMIN="ادمین";

	$MSG_STANDING="جایگاه ها";

	$MSG_STATISTICS="آمار";

	$MSG_USERINFO="اصلاح اطلاعات";
	$MSG_MAIL="پست الکترونیکی";
	//status.php

	
	$MSG_Pending="در انتظار";

	$MSG_Pending_Rejudging="انتظار برای بررسی مجدد";

	$MSG_Compiling="در حال کامپایل";

	$MSG_Running_Judging="در حال اجرا و قضاوت";

	$MSG_Accepted="پذیرفته شد";

	$MSG_Presentation_Error="خطای ارایه";

	$MSG_Wrong_Answer="جواب اشتباه";

	$MSG_Time_Limit_Exceed="تجاوز از محدوده زمان";

	$MSG_Memory_Limit_Exceed="تجاوز از محدوده حافظه";

	$MSG_Output_Limit_Exceed="تجاوز از محدوده خروجی";

	$MSG_Runtime_Error="خطای زمان اجرا";

	$MSG_Compile_Error="خطای کامپایل";

	$MSG_Compile_OK="تایید کامپایل";

	$MSG_RUNID="شناسه اجرا";

	$MSG_USER="کاربر";

	$MSG_PROBLEM="مسئله";

	$MSG_RESULT="نتیجه";

	$MSG_MEMORY="حافظه";

	$MSG_TIME="زمان";

	$MSG_LANG="زبان";

	$MSG_CODE_LENGTH="طول کد";

	$MSG_SUBMIT_TIME="زمان ارسال";

	//problemstatistics.php

	$MSG_PD="PD";

	$MSG_PR="PR";

	$MSG_CI="CI";

	$MSG_RJ="RJ";

	$MSG_AC="AC";

	$MSG_PE="PE";

	$MSG_WA="WA";

	$MSG_TLE="TLE";

	$MSG_MLE="MLE";

	$MSG_OLE="OLE";

	$MSG_RE="RE";

	$MSG_CE="CE";

	$MSG_CO="CO";

	
//problemset.php

	$MSG_SEARCH="جستجو";

	$MSG_PROBLEM_ID="شناسه مسئله";

	$MSG_TITLE="عنوان";

	$MSG_SOURCE="منبع";

	$MSG_SUBMIT="ارسال";

	
//ranklist.php

	$MSG_Number="شماره";

	$MSG_NICK="لقب";

	$MSG_SOVLED="مسائل حل کرده";

	$MSG_RATIO="سهم";

	//registerpage.php

	$MSG_USER_ID="شناسه کاربری";

	$MSG_PASSWORD="رمز عبور";

	$MSG_REPEAT_PASSWORD="تکرار رمز عبور";

	$MSG_SCHOOL="مدرسه";

	$MSG_EMAIL="ایمیل";

	$MSG_REG_INFO="اطلاعات عضویت";
	$MSG_VCODE="کد امنیتی";


	//problem.php

	$MSG_NO_SUCH_PROBLEM="فعلا امکان دسترسی به این سوال نیست";

	$MSG_Description="توضیحات";

	$MSG_Input="ورودی";

	$MSG_Output= "خروجی";

	$MSG_Sample_Input= "نمونه وردی";

	$MSG_Sample_Output= "نمونه خروجی";

	$MSG_HINT= "تذکر";

	$MSG_Source= "منبع";

	$MSG_Time_Limit="محدودیت زمانی";

	$MSG_Memory_Limit="محدودیت حجمی";
//admin menu
	$MSG_SEEOJ="نمایش";
	$MSG_ADD="ایجاد ";
	$MSG_LIST="لیست";
	$MSG_NEWS="خبرها";
	$MSG_TEAMGENERATOR="ساخت تیم";
	$MSG_SETMESSAGE="تنظیم پیام";
	$MSG_SETPASSWORD="تغییر رمز";
	$MSG_REJUDGE="داوری مجدد";
	$MSG_PRIVILEGE="امتیاز";
	$MSG_GIVESOURCE="دادن منبع";
	$MSG_IMPORT="وارد کردن";
	$MSG_EXPORT="صادر کردن";
	$MSG_UPDATE_DATABASE="به روز رسانی پایگاه داد";
	$MSG_ONLINE="بر خط";
   //someone please translate these
  $MSG_PRIVATE_WARNING="This is a private contest which you don't have privilege。";
  $MSG_WATCH_RANK="Click HERE to watch contest rank.";
  $MSG_Public="Public";
  $MSG_Private="Private";
  $MSG_Running="Running";
  $MSG_Start="Start";
  $MSG_TotalTime="Total";
  $MSG_LeftTime="Left";
$MSG_Ended="Finished";

?>
